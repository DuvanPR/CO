脚本特性：

- 更新Andrio SDK到10月30日版本

- 在鼠标右键中加入终端快捷方式

- 集成必备库以及其他必备内容

- 集成51-android.rules

- 移除smarthosts

- 更新ccache到3.1

- 更新python到3.3.2

- 更新GNU Make到3.8.2

- 集成安卓厨房

- 解决repo无法下载问题（感谢laser杨万荣）

- 集成JDK

- 集成Git

使用方法：

打开打开终端，输入以下命令给予权限：

sudo chmod 775 auto.sh

再输入以下命令。

./auto.sh

然后根据提示进行配置。
